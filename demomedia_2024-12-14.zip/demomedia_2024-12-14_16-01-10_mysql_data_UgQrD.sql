-- MySQL dump 10.13  Distrib 8.0.36, for Linux (x86_64)
--
-- Host: localhost    Database: demomedia
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `rc_config`
--

DROP TABLE IF EXISTS `rc_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rc_config` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'id',
  `createAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `appName` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '所属应用',
  `key` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '键',
  `value` text COLLATE utf8mb4_general_ci COMMENT '值',
  `type` int NOT NULL DEFAULT '0' COMMENT '此键值对的所属安全状态，0仅管理员可见，1登陆可见，2公开',
  `status` int NOT NULL DEFAULT '1' COMMENT '使用状态，1开启，0关闭',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='网站配置';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rc_config`
--

LOCK TABLES `rc_config` WRITE;
/*!40000 ALTER TABLE `rc_config` DISABLE KEYS */;
/*!40000 ALTER TABLE `rc_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rc_emby_user`
--

DROP TABLE IF EXISTS `rc_emby_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rc_emby_user` (
  `id` int NOT NULL AUTO_INCREMENT,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'createdAt',
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'updatedAt',
  `activateTo` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '激活到某一时刻',
  `userId` int NOT NULL COMMENT '本系统用户id',
  `embyId` varchar(64) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'emby注册用户id',
  `userInfo` text COLLATE utf8mb4_general_ci COMMENT '其他信息(json)',
  PRIMARY KEY (`id`),
  UNIQUE KEY `rc_emby_user_pk_2` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rc_emby_user`
--

LOCK TABLES `rc_emby_user` WRITE;
/*!40000 ALTER TABLE `rc_emby_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `rc_emby_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rc_exchange_code`
--

DROP TABLE IF EXISTS `rc_exchange_code`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rc_exchange_code` (
  `id` int NOT NULL AUTO_INCREMENT,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `code` varchar(64) COLLATE utf8mb4_general_ci NOT NULL COMMENT '激活码',
  `type` int NOT NULL DEFAULT '0' COMMENT '0未使用，1已使用，-1已禁用',
  `exchangeType` int NOT NULL DEFAULT '1' COMMENT '可兑换类型（1激活，2按天续期，3按月续期，4充值余额）',
  `exchangeCount` int NOT NULL DEFAULT '1' COMMENT '兑换数量',
  `exchangeDate` timestamp NULL DEFAULT NULL COMMENT '兑换日期',
  `usedByUserId` int DEFAULT NULL COMMENT '被用户（ID）使用',
  `codeInfo` text COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `rc_exchange_code_pk_2` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='激活码';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rc_exchange_code`
--

LOCK TABLES `rc_exchange_code` WRITE;
/*!40000 ALTER TABLE `rc_exchange_code` DISABLE KEYS */;
/*!40000 ALTER TABLE `rc_exchange_code` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rc_finance_record`
--

DROP TABLE IF EXISTS `rc_finance_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rc_finance_record` (
  `id` int NOT NULL AUTO_INCREMENT,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `userId` int DEFAULT NULL COMMENT '对应用户id',
  `action` int DEFAULT NULL COMMENT '1充值，2兑换兑换码，3使用余额',
  `count` varchar(64) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '充值消费则显示数量，兑换激活码填入对应激活码',
  `recordInfo` text COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `rc_finance_record_pk_2` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='交易记录';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rc_finance_record`
--

LOCK TABLES `rc_finance_record` WRITE;
/*!40000 ALTER TABLE `rc_finance_record` DISABLE KEYS */;
/*!40000 ALTER TABLE `rc_finance_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rc_media_comment`
--

DROP TABLE IF EXISTS `rc_media_comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rc_media_comment` (
  `id` int NOT NULL AUTO_INCREMENT,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `userId` int NOT NULL COMMENT '用户id',
  `mediaId` varchar(64) COLLATE utf8mb4_general_ci NOT NULL COMMENT '媒体id',
  `rating` double NOT NULL DEFAULT '5',
  `comment` text COLLATE utf8mb4_general_ci,
  `mentions` text COLLATE utf8mb4_general_ci,
  `quotedComment` int DEFAULT NULL COMMENT '引用的评论id',
  PRIMARY KEY (`id`),
  UNIQUE KEY `rc_media_comment_pk_2` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='评论';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rc_media_comment`
--

LOCK TABLES `rc_media_comment` WRITE;
/*!40000 ALTER TABLE `rc_media_comment` DISABLE KEYS */;
/*!40000 ALTER TABLE `rc_media_comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rc_media_history`
--

DROP TABLE IF EXISTS `rc_media_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rc_media_history` (
  `id` int NOT NULL AUTO_INCREMENT,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `type` int NOT NULL DEFAULT '1' COMMENT '1播放中 2暂停 3完成播放',
  `userId` int NOT NULL,
  `mediaId` varchar(64) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `mediaName` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `mediaYear` varchar(16) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `historyInfo` text COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `rc_media_history_pk_2` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='播放历史';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rc_media_history`
--

LOCK TABLES `rc_media_history` WRITE;
/*!40000 ALTER TABLE `rc_media_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `rc_media_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rc_media_info`
--

DROP TABLE IF EXISTS `rc_media_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rc_media_info` (
  `id` int NOT NULL AUTO_INCREMENT,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `mediaName` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `mediaYear` varchar(8) COLLATE utf8mb4_general_ci NOT NULL,
  `mediaType` int NOT NULL DEFAULT '1' COMMENT '1电影 2剧集',
  `mediaMainId` varchar(64) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'Emby中对应的主要id，用于图片获取',
  `mediaInfo` text COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `rc_media_info_pk_2` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rc_media_info`
--

LOCK TABLES `rc_media_info` WRITE;
/*!40000 ALTER TABLE `rc_media_info` DISABLE KEYS */;
/*!40000 ALTER TABLE `rc_media_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rc_memo`
--

DROP TABLE IF EXISTS `rc_memo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rc_memo` (
  `id` int NOT NULL AUTO_INCREMENT,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `userId` int NOT NULL COMMENT '用户id',
  `type` int NOT NULL DEFAULT '1' COMMENT '类型，1公开，0指定好友可见，-1删除',
  `content` text COLLATE utf8mb4_general_ci COMMENT '内容',
  `memoInfo` text COLLATE utf8mb4_general_ci COMMENT '存储json类型数据',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rc_memo`
--

LOCK TABLES `rc_memo` WRITE;
/*!40000 ALTER TABLE `rc_memo` DISABLE KEYS */;
/*!40000 ALTER TABLE `rc_memo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rc_memo_comment`
--

DROP TABLE IF EXISTS `rc_memo_comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rc_memo_comment` (
  `id` int NOT NULL AUTO_INCREMENT,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `memoId` int NOT NULL,
  `userId` int DEFAULT NULL,
  `userName` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `replyTo` int DEFAULT NULL,
  `type` int NOT NULL DEFAULT '1',
  `content` text COLLATE utf8mb4_general_ci,
  `commentInfo` text COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rc_memo_comment`
--

LOCK TABLES `rc_memo_comment` WRITE;
/*!40000 ALTER TABLE `rc_memo_comment` DISABLE KEYS */;
/*!40000 ALTER TABLE `rc_memo_comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rc_notification`
--

DROP TABLE IF EXISTS `rc_notification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rc_notification` (
  `id` int NOT NULL AUTO_INCREMENT,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `type` int NOT NULL DEFAULT '0' COMMENT '0系统通知 1用户消息',
  `readStatus` int NOT NULL DEFAULT '0' COMMENT '0未读 1已读',
  `fromUserId` int NOT NULL DEFAULT '0' COMMENT '0系统 >0用户',
  `toUserId` int NOT NULL,
  `message` text COLLATE utf8mb4_general_ci,
  `notificationInfo` text COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `rc_notification_pk_2` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='通知';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rc_notification`
--

LOCK TABLES `rc_notification` WRITE;
/*!40000 ALTER TABLE `rc_notification` DISABLE KEYS */;
/*!40000 ALTER TABLE `rc_notification` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rc_pay_record`
--

DROP TABLE IF EXISTS `rc_pay_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rc_pay_record` (
  `id` int NOT NULL AUTO_INCREMENT,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `payCompleteKey` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `type` int NOT NULL DEFAULT '0',
  `userId` int NOT NULL,
  `tradeNo` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `money` varchar(64) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `clientip` varchar(64) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `payRecordInfo` text COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `pay_record_pk_2` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='支付记录';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rc_pay_record`
--

LOCK TABLES `rc_pay_record` WRITE;
/*!40000 ALTER TABLE `rc_pay_record` DISABLE KEYS */;
/*!40000 ALTER TABLE `rc_pay_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rc_request`
--

DROP TABLE IF EXISTS `rc_request`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rc_request` (
  `id` int NOT NULL AUTO_INCREMENT,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `type` int NOT NULL DEFAULT '1' COMMENT '0暂不请求，1请求未回复，2已经回复，-1已关闭',
  `requestUserId` int NOT NULL,
  `replyUserId` int DEFAULT NULL COMMENT '回复的管理员id',
  `message` text COLLATE utf8mb4_general_ci COMMENT '对话记录',
  `requestInfo` text COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `rc_request_pk_2` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='emby求片';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rc_request`
--

LOCK TABLES `rc_request` WRITE;
/*!40000 ALTER TABLE `rc_request` DISABLE KEYS */;
/*!40000 ALTER TABLE `rc_request` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rc_telegram_user`
--

DROP TABLE IF EXISTS `rc_telegram_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rc_telegram_user` (
  `id` int NOT NULL AUTO_INCREMENT,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `userId` int NOT NULL,
  `telegramId` varchar(64) COLLATE utf8mb4_general_ci NOT NULL,
  `type` int NOT NULL DEFAULT '1' COMMENT '1正常绑定，2已经解绑',
  `userInfo` text COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `rc_telegram_user_pk_2` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='电报用户信息';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rc_telegram_user`
--

LOCK TABLES `rc_telegram_user` WRITE;
/*!40000 ALTER TABLE `rc_telegram_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `rc_telegram_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rc_user`
--

DROP TABLE IF EXISTS `rc_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rc_user` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'id',
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'createdAt',
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'updatedAt',
  `userName` varchar(255) COLLATE utf8mb4_general_ci NOT NULL COMMENT '用户名（登陆名称）',
  `nickName` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `authority` int NOT NULL DEFAULT '1' COMMENT '权限（1:注册用户，之后数字为等级，0为管理员',
  `email` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `rCoin` double NOT NULL DEFAULT '0' COMMENT '余额',
  `userInfo` text COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='用户表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rc_user`
--

LOCK TABLES `rc_user` WRITE;
/*!40000 ALTER TABLE `rc_user` DISABLE KEYS */;
INSERT INTO `rc_user` VALUES (1,'2024-12-14 08:00:35','2024-12-14 08:00:35','admin','admin','$2y$10$rJff.jXkgLpFBN0qE9B.Uu/gnlH2WsUqblAMJOH4iNg7w7OjKJZG6',0,'randall@randallanjie.com',0,NULL);
/*!40000 ALTER TABLE `rc_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rc_version_updates`
--

DROP TABLE IF EXISTS `rc_version_updates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rc_version_updates` (
  `id` int NOT NULL AUTO_INCREMENT,
  `app_name` varchar(50) NOT NULL DEFAULT 'ALL' COMMENT '应用名称,ALL表示全部应用',
  `version` varchar(20) DEFAULT NULL COMMENT '版本号',
  `description` text COMMENT '更新说明',
  `download_url` varchar(255) DEFAULT NULL COMMENT '下载地址',
  `is_release` tinyint(1) DEFAULT '0' COMMENT '是否发布:0=未发布,1=已发布',
  `createdAt` datetime DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_app_version` (`app_name`,`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rc_version_updates`
--

LOCK TABLES `rc_version_updates` WRITE;
/*!40000 ALTER TABLE `rc_version_updates` DISABLE KEYS */;
/*!40000 ALTER TABLE `rc_version_updates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'demomedia'
--

--
-- Dumping routines for database 'demomedia'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-12-14 16:01:10
